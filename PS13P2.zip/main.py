
class Student:
  def __init__(self, first, last, district, credits):
    self.first = first
    self.last = last
    self.district = district
    self.credits = credits

  def tuition(self):
    credit = 0.0
    if (self.district) == 'I':
     credit = 250.00
    else:
     credit = 500.00

    t = float(credit) * float(self.credits)
    return t

stud = Student('Joseph', 'Choi', 'O', 15)

print(stud.first)
print(stud.last)
print("District Code: ", stud.district)
print(stud.tuition())




    
    
    
  